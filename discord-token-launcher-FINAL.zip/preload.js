const { contextBridge, ipcRenderer } = require('electron');

// Expose API URL and utilities to renderer
contextBridge.exposeInMainWorld('electronAPI', {
  getBackendUrl: () => 'http://127.0.0.1:8001',
  isElectron: true,
  platform: process.platform
});

// Also set it on window for compatibility
window.BACKEND_URL = 'http://127.0.0.1:8001';
