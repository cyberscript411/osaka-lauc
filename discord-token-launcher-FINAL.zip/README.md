# Discord Token Launcher

## 🚀 Installation Rapide (Windows)

### Prérequis
1. **Python 3.8+** - [Télécharger ici](https://www.python.org/downloads/)
   - ⚠️ **IMPORTANT**: Cochez "Add Python to PATH" lors de l'installation!
2. **Node.js 18+** - [Télécharger ici](https://nodejs.org/)

### Installation
1. **Double-cliquez sur `install.bat`** pour installer automatiquement toutes les dépendances

   OU installez manuellement:
   ```bash
   # Installer les dépendances Python
   cd backend
   pip install -r requirements.txt
   cd ..
   
   # Installer les dépendances Node
   npm install
   ```

### Lancement
- **Double-cliquez sur `start.bat`**

  OU lancez manuellement:
  ```bash
  npm start
  ```

## ❗ Dépannage

### "Le backend n'a pas démarré correctement"
1. Ouvrez un terminal (cmd) dans le dossier
2. Exécutez:
   ```bash
   cd backend
   pip install -r requirements.txt
   python -m uvicorn server:app --host 127.0.0.1 --port 8001
   ```
3. Si ça fonctionne, relancez l'application

### Python non trouvé
1. Réinstallez Python depuis python.org
2. **Cochez "Add Python to PATH"** lors de l'installation
3. Redémarrez votre PC

### Erreur de module manquant
```bash
pip install fastapi uvicorn aiohttp websockets pydantic motor python-dotenv
```

## 📋 Fonctionnalités
- 🎙️ Connexion vocale multi-tokens
- 📨 Spam de messages
- 🔄 Changement de statut
- 📝 Changement de pseudo
- 💬 DM en masse
- ⚡ Auto-Captcha (CapMonster)
