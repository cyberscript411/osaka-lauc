@echo off
echo ====================================
echo   Discord Token Launcher - Setup
echo ====================================
echo.

REM Check Python
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERREUR] Python n'est pas installe!
    echo Telechargez Python depuis: https://www.python.org/downloads/
    echo.
    echo IMPORTANT: Cochez "Add Python to PATH" lors de l'installation!
    pause
    exit /b 1
)

echo [OK] Python trouve
python --version

REM Install dependencies
echo.
echo Installation des dependances Python...
cd backend
pip install -r requirements.txt
if %errorlevel% neq 0 (
    echo [ERREUR] Echec de l'installation des dependances
    pause
    exit /b 1
)
cd ..

echo.
echo [OK] Dependances installees

REM Install Node modules
echo.
echo Installation des modules Node.js...
call npm install
if %errorlevel% neq 0 (
    echo [ERREUR] Echec de npm install
    echo Assurez-vous que Node.js est installe
    pause
    exit /b 1
)

echo.
echo ====================================
echo   Installation terminee!
echo ====================================
echo.
echo Pour lancer l'application:
echo   npm start
echo.
pause
