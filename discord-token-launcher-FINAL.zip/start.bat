@echo off
echo Demarrage du Token Launcher...
echo.

REM Check if backend dependencies are installed
python -c "import uvicorn" >nul 2>&1
if %errorlevel% neq 0 (
    echo Installation des dependances Python...
    cd backend
    pip install -r requirements.txt
    cd ..
)

REM Start the app
npm start
