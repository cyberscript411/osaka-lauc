from fastapi import FastAPI, APIRouter, HTTPException
from fastapi.responses import FileResponse
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field, ConfigDict
from typing import List, Optional, Dict
import uuid
from datetime import datetime, timezone
import asyncio
import aiohttp
import json
import random

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

app = FastAPI()
api_router = APIRouter(prefix="/api")

# Global state
token_connections: Dict[str, dict] = {}
active_tasks: Dict[str, asyncio.Task] = {}
spam_tasks: Dict[str, asyncio.Task] = {}
dm_all_tasks: Dict[str, asyncio.Task] = {}
dm_all_progress: Dict[str, dict] = {}

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

DISCORD_API = "https://discord.com/api/v10"

# ============ MODELS ============

class TokenItem(BaseModel):
    token: str
    label: Optional[str] = None
    status: str = "idle"

class ConfigurationCreate(BaseModel):
    name: str
    guild_id: str
    channel_id: str
    tokens: List[TokenItem]

class Configuration(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    guild_id: str
    channel_id: str
    tokens: List[TokenItem]
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class LaunchRequest(BaseModel):
    guild_id: str
    channel_id: str
    tokens: List[str]
    invite_code: Optional[str] = None

class SpamRequest(BaseModel):
    channel_id: str
    tokens: List[str]
    messages: List[str]
    delay: float = 1.0
    random_delay: bool = False

class StatusRequest(BaseModel):
    tokens: List[str]
    status: str

class NicknameRequest(BaseModel):
    guild_id: str
    tokens: List[str]
    nickname: str

class ReactionRequest(BaseModel):
    channel_id: str
    message_id: str
    tokens: List[str]
    emoji: str

class DMRequest(BaseModel):
    user_id: str
    tokens: List[str]
    message: str

class DMAllFriendsRequest(BaseModel):
    tokens: List[str]
    message: str
    delay: float = 1.0

class DMAllServerRequest(BaseModel):
    guild_id: str
    tokens: List[str]
    message: str
    delay: float = 1.0

class ExtractTokensRequest(BaseModel):
    text: str

# ============ HELPERS ============

def get_headers(token: str) -> dict:
    return {
        "Authorization": token,
        "Content-Type": "application/json",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
    }

async def validate_token(session: aiohttp.ClientSession, token: str) -> dict:
    try:
        async with session.get(f"{DISCORD_API}/users/@me", headers=get_headers(token)) as resp:
            if resp.status == 200:
                data = await resp.json()
                return {"valid": True, "username": f"{data['username']}#{data.get('discriminator', '0')}", "id": data["id"]}
            elif resp.status == 401:
                return {"valid": False, "error": "Token invalide ou expiré"}
            else:
                return {"valid": False, "error": f"Erreur: {resp.status}"}
    except Exception as e:
        return {"valid": False, "error": str(e)}

async def join_server_with_invite(session: aiohttp.ClientSession, token: str, invite_code: str) -> dict:
    if "discord.gg/" in invite_code:
        invite_code = invite_code.split("discord.gg/")[-1]
    elif "discord.com/invite/" in invite_code:
        invite_code = invite_code.split("discord.com/invite/")[-1]
    invite_code = invite_code.strip().split("?")[0].split("/")[0]
    
    try:
        async with session.post(f"{DISCORD_API}/invites/{invite_code}", headers=get_headers(token)) as resp:
            if resp.status == 200:
                data = await resp.json()
                return {"success": True, "guild_name": data.get("guild", {}).get("name", "Unknown")}
            else:
                return {"success": False, "error": f"Erreur: {resp.status}"}
    except Exception as e:
        return {"success": False, "error": str(e)}

def extract_discord_tokens(text: str) -> List[str]:
    import re
    pattern = r'[MNO][A-Za-z0-9_-]{17,}[A-Za-z0-9]\.[A-Za-z0-9_-]{6}\.[A-Za-z0-9_-]{27,38}'
    matches = re.findall(pattern, text)
    unique_tokens = []
    for token in matches:
        is_substring = any(token in existing for existing in unique_tokens)
        if not is_substring:
            unique_tokens = [t for t in unique_tokens if t not in token]
            unique_tokens.append(token)
    return unique_tokens

# ============ VOICE FUNCTIONS ============

async def join_voice_channel(session: aiohttp.ClientSession, token: str, guild_id: str, channel_id: str, token_id: str, invite_code: Optional[str] = None):
    import websockets
    
    token_connections[token_id] = {"status": "connecting", "error": None, "username": None}
    
    try:
        validation = await validate_token(session, token)
        if not validation["valid"]:
            token_connections[token_id] = {"status": "error", "error": validation["error"], "username": None}
            return
        
        username = validation["username"]
        token_connections[token_id]["username"] = username
        
        async with session.get(f"{DISCORD_API}/guilds/{guild_id}", headers=get_headers(token)) as resp:
            if resp.status == 404:
                if invite_code:
                    join_result = await join_server_with_invite(session, token, invite_code)
                    if not join_result["success"]:
                        token_connections[token_id] = {"status": "error", "error": join_result['error'], "username": username}
                        return
                    await asyncio.sleep(2)
                else:
                    token_connections[token_id] = {"status": "error", "error": "Pas dans le serveur", "username": username}
                    return
        
        async with session.get(f"{DISCORD_API}/gateway") as resp:
            gateway_data = await resp.json()
            gateway_url = gateway_data["url"] + "?v=10&encoding=json"
        
        async with websockets.connect(gateway_url) as ws:
            hello = json.loads(await ws.recv())
            heartbeat_interval = hello["d"]["heartbeat_interval"] / 1000
            
            await ws.send(json.dumps({
                "op": 2,
                "d": {
                    "token": token,
                    "intents": 1 << 7 | 1 << 0,
                    "properties": {"os": "windows", "browser": "chrome", "device": "pc"}
                }
            }))
            
            async def heartbeat_loop():
                while True:
                    await asyncio.sleep(heartbeat_interval)
                    await ws.send(json.dumps({"op": 1, "d": None}))
            
            heartbeat_task = asyncio.create_task(heartbeat_loop())
            
            try:
                for _ in range(20):
                    try:
                        msg = await asyncio.wait_for(ws.recv(), timeout=10)
                        event = json.loads(msg)
                        if event.get("op") == 0 and event.get("t") == "READY":
                            break
                    except asyncio.TimeoutError:
                        continue
                
                await ws.send(json.dumps({
                    "op": 4,
                    "d": {"guild_id": guild_id, "channel_id": channel_id, "self_mute": False, "self_deaf": True}
                }))
                
                for _ in range(15):
                    try:
                        msg = await asyncio.wait_for(ws.recv(), timeout=5)
                        event = json.loads(msg)
                        if event.get("op") == 0 and event.get("t") == "VOICE_STATE_UPDATE":
                            if event["d"].get("channel_id") == channel_id:
                                token_connections[token_id] = {"status": "connected", "error": None, "username": username}
                                break
                    except asyncio.TimeoutError:
                        continue
                
                while token_connections.get(token_id, {}).get("status") == "connected":
                    try:
                        msg = await asyncio.wait_for(ws.recv(), timeout=heartbeat_interval + 5)
                        event = json.loads(msg)
                        if event.get("op") == 0 and event.get("t") == "VOICE_STATE_UPDATE":
                            if event["d"].get("channel_id") is None:
                                token_connections[token_id] = {"status": "disconnected", "error": None, "username": username}
                                break
                    except:
                        break
                        
            finally:
                heartbeat_task.cancel()
                
    except Exception as e:
        token_connections[token_id] = {"status": "error", "error": str(e)[:50], "username": token_connections.get(token_id, {}).get("username")}

async def launch_token(token: str, guild_id: str, channel_id: str, token_id: str, invite_code: Optional[str] = None):
    async with aiohttp.ClientSession() as session:
        await join_voice_channel(session, token, guild_id, channel_id, token_id, invite_code)

# ============ SPAM FUNCTIONS ============

async def spam_messages(token: str, channel_id: str, messages: List[str], delay: float, random_delay: bool, task_id: str):
    async with aiohttp.ClientSession() as session:
        validation = await validate_token(session, token)
        if not validation["valid"]:
            return
        
        while task_id in spam_tasks:
            message = random.choice(messages)
            try:
                async with session.post(
                    f"{DISCORD_API}/channels/{channel_id}/messages",
                    headers=get_headers(token),
                    json={"content": message}
                ) as resp:
                    if resp.status == 429:
                        data = await resp.json()
                        await asyncio.sleep(data.get("retry_after", 5))
            except Exception as e:
                logger.error(f"Spam error: {e}")
            
            wait_time = delay
            if random_delay:
                wait_time = random.uniform(delay * 0.5, delay * 1.5)
            await asyncio.sleep(wait_time)

# ============ STATUS FUNCTIONS ============

async def change_status(token: str, status: str) -> dict:
    import websockets
    
    async with aiohttp.ClientSession() as session:
        try:
            async with session.get(f"{DISCORD_API}/gateway") as resp:
                gateway_data = await resp.json()
                gateway_url = gateway_data["url"] + "?v=10&encoding=json"
            
            async with websockets.connect(gateway_url) as ws:
                await ws.recv()
                await ws.send(json.dumps({
                    "op": 2,
                    "d": {
                        "token": token,
                        "intents": 0,
                        "properties": {"os": "windows", "browser": "chrome", "device": "pc"},
                        "presence": {"status": status, "since": 0, "activities": [], "afk": False}
                    }
                }))
                await asyncio.sleep(2)
                return {"success": True}
        except Exception as e:
            return {"success": False, "error": str(e)}

# ============ OTHER FUNCTIONS ============

async def change_nickname(session: aiohttp.ClientSession, token: str, guild_id: str, nickname: str) -> dict:
    try:
        async with session.patch(
            f"{DISCORD_API}/guilds/{guild_id}/members/@me",
            headers=get_headers(token),
            json={"nick": nickname}
        ) as resp:
            return {"success": resp.status == 200}
    except Exception as e:
        return {"success": False, "error": str(e)}

async def add_reaction(session: aiohttp.ClientSession, token: str, channel_id: str, message_id: str, emoji: str) -> dict:
    import urllib.parse
    try:
        encoded_emoji = urllib.parse.quote(emoji)
        async with session.put(
            f"{DISCORD_API}/channels/{channel_id}/messages/{message_id}/reactions/{encoded_emoji}/@me",
            headers=get_headers(token)
        ) as resp:
            return {"success": resp.status == 204}
    except Exception as e:
        return {"success": False, "error": str(e)}

async def send_dm(session: aiohttp.ClientSession, token: str, user_id: str, message: str) -> dict:
    try:
        async with session.post(
            f"{DISCORD_API}/users/@me/channels",
            headers=get_headers(token),
            json={"recipient_id": user_id}
        ) as resp:
            if resp.status != 200:
                return {"success": False, "error": "Cannot create DM"}
            dm_data = await resp.json()
        
        async with session.post(
            f"{DISCORD_API}/channels/{dm_data['id']}/messages",
            headers=get_headers(token),
            json={"content": message}
        ) as resp:
            return {"success": resp.status == 200}
    except Exception as e:
        return {"success": False, "error": str(e)}

async def get_friends(session: aiohttp.ClientSession, token: str) -> list:
    """Get all friends of a token"""
    try:
        async with session.get(
            f"{DISCORD_API}/users/@me/relationships",
            headers=get_headers(token)
        ) as resp:
            if resp.status == 200:
                relationships = await resp.json()
                # Filter only friends (type 1)
                friends = [r for r in relationships if r.get("type") == 1]
                return friends
            return []
    except:
        return []

async def get_guild_members(session: aiohttp.ClientSession, token: str, guild_id: str) -> list:
    """Get all members of a guild"""
    members = []
    try:
        after = "0"
        while True:
            async with session.get(
                f"{DISCORD_API}/guilds/{guild_id}/members?limit=1000&after={after}",
                headers=get_headers(token)
            ) as resp:
                if resp.status != 200:
                    break
                batch = await resp.json()
                if not batch:
                    break
                members.extend(batch)
                if len(batch) < 1000:
                    break
                after = batch[-1]["user"]["id"]
                await asyncio.sleep(0.5)  # Rate limit
        return members
    except:
        return members

async def dm_all_friends_task(token: str, message: str, delay: float, task_id: str):
    """Send DM to all friends of a token"""
    async with aiohttp.ClientSession() as session:
        validation = await validate_token(session, token)
        if not validation["valid"]:
            return {"sent": 0, "failed": 0, "error": validation["error"]}
        
        friends = await get_friends(session, token)
        sent = 0
        failed = 0
        
        for friend in friends:
            if task_id not in dm_all_tasks:
                break  # Task was cancelled
            
            user_id = friend.get("id")
            if not user_id:
                continue
            
            result = await send_dm(session, token, user_id, message)
            if result.get("success"):
                sent += 1
            else:
                failed += 1
            
            await asyncio.sleep(delay)
        
        return {"sent": sent, "failed": failed, "total_friends": len(friends)}

async def dm_all_server_task(token: str, guild_id: str, message: str, delay: float, task_id: str):
    """Send DM to all members of a server"""
    async with aiohttp.ClientSession() as session:
        validation = await validate_token(session, token)
        if not validation["valid"]:
            return {"sent": 0, "failed": 0, "error": validation["error"]}
        
        # Get current user ID to exclude self
        current_user_id = validation.get("id")
        
        members = await get_guild_members(session, token, guild_id)
        sent = 0
        failed = 0
        
        for member in members:
            if task_id not in dm_all_tasks:
                break  # Task was cancelled
            
            user = member.get("user", {})
            user_id = user.get("id")
            
            # Skip bots and self
            if not user_id or user.get("bot") or user_id == current_user_id:
                continue
            
            result = await send_dm(session, token, user_id, message)
            if result.get("success"):
                sent += 1
            else:
                failed += 1
            
            await asyncio.sleep(delay)
        
        return {"sent": sent, "failed": failed, "total_members": len(members)}

# ============ API ROUTES ============

@api_router.get("/")
async def root():
    return {"message": "Discord Token Launcher API - Multi-Tools"}

# Download ZIP
@api_router.get("/download-zip")
async def download_zip():
    zip_path = "/app/discord-token-launcher-electron.zip"
    if os.path.exists(zip_path):
        return FileResponse(zip_path, filename="discord-token-launcher-electron.zip", media_type="application/zip")
    raise HTTPException(status_code=404, detail="ZIP file not found")

# Configurations
@api_router.post("/configurations", response_model=Configuration)
async def create_configuration(config: ConfigurationCreate):
    config_obj = Configuration(**config.model_dump())
    doc = config_obj.model_dump()
    doc['created_at'] = doc['created_at'].isoformat()
    doc['updated_at'] = doc['updated_at'].isoformat()
    await db.configurations.insert_one(doc)
    return config_obj

@api_router.get("/configurations", response_model=List[Configuration])
async def get_configurations():
    configs = await db.configurations.find({}, {"_id": 0}).to_list(100)
    for config in configs:
        if isinstance(config.get('created_at'), str):
            config['created_at'] = datetime.fromisoformat(config['created_at'])
        if isinstance(config.get('updated_at'), str):
            config['updated_at'] = datetime.fromisoformat(config['updated_at'])
    return configs

@api_router.delete("/configurations/{config_id}")
async def delete_configuration(config_id: str):
    await db.configurations.delete_one({"id": config_id})
    return {"message": "Deleted"}

# Voice
@api_router.post("/launch")
async def launch_tokens(request: LaunchRequest):
    token_ids = []
    tokens_to_launch = []
    
    for i, token in enumerate(request.tokens):
        token_stripped = token.strip()
        if not token_stripped:
            continue
        token_id = f"token_{i}_{uuid.uuid4().hex[:8]}"
        token_ids.append(token_id)
        token_connections[token_id] = {"status": "pending", "error": None, "username": None}
        tokens_to_launch.append((token_stripped, token_id))
    
    async def launch_batch():
        for i in range(0, len(tokens_to_launch), 5):
            batch = tokens_to_launch[i:i + 5]
            for token_stripped, token_id in batch:
                task = asyncio.create_task(launch_token(token_stripped, request.guild_id, request.channel_id, token_id, request.invite_code))
                active_tasks[token_id] = task
            if i + 5 < len(tokens_to_launch):
                await asyncio.sleep(2)
    
    asyncio.create_task(launch_batch())
    return {"message": "Launch initiated", "token_ids": token_ids}

@api_router.get("/status")
async def get_token_status():
    return token_connections

@api_router.post("/disconnect")
async def disconnect_all():
    for task in active_tasks.values():
        task.cancel()
    active_tasks.clear()
    token_connections.clear()
    return {"message": "Disconnected"}

# Spam
@api_router.post("/spam/start")
async def start_spam(request: SpamRequest):
    task_ids = []
    for i, token in enumerate(request.tokens):
        token_stripped = token.strip()
        if not token_stripped:
            continue
        task_id = f"spam_{i}_{uuid.uuid4().hex[:8]}"
        task_ids.append(task_id)
        task = asyncio.create_task(spam_messages(token_stripped, request.channel_id, request.messages, request.delay, request.random_delay, task_id))
        spam_tasks[task_id] = task
    return {"message": "Spam started", "task_ids": task_ids}

@api_router.post("/spam/stop")
async def stop_spam():
    for task in spam_tasks.values():
        task.cancel()
    spam_tasks.clear()
    return {"message": "Spam stopped"}

# Status
@api_router.post("/status/change")
async def change_all_status(request: StatusRequest):
    results = []
    for token in request.tokens:
        if token.strip():
            results.append(await change_status(token.strip(), request.status))
    success = sum(1 for r in results if r.get("success"))
    return {"message": f"Status changed for {success}/{len(results)} tokens"}

# Nickname
@api_router.post("/nickname/change")
async def change_all_nicknames(request: NicknameRequest):
    results = []
    async with aiohttp.ClientSession() as session:
        for token in request.tokens:
            if token.strip():
                results.append(await change_nickname(session, token.strip(), request.guild_id, request.nickname))
                await asyncio.sleep(0.5)
    success = sum(1 for r in results if r.get("success"))
    return {"message": f"Nickname changed for {success}/{len(results)} tokens"}

# Reactions
@api_router.post("/reaction/add")
async def add_all_reactions(request: ReactionRequest):
    results = []
    async with aiohttp.ClientSession() as session:
        for token in request.tokens:
            if token.strip():
                results.append(await add_reaction(session, token.strip(), request.channel_id, request.message_id, request.emoji))
                await asyncio.sleep(0.3)
    success = sum(1 for r in results if r.get("success"))
    return {"message": f"Reaction added by {success}/{len(results)} tokens"}

# DM
@api_router.post("/dm/send")
async def send_all_dms(request: DMRequest):
    results = []
    async with aiohttp.ClientSession() as session:
        for token in request.tokens:
            if token.strip():
                results.append(await send_dm(session, token.strip(), request.user_id, request.message))
                await asyncio.sleep(1)
    success = sum(1 for r in results if r.get("success"))
    return {"message": f"DM sent by {success}/{len(results)} tokens"}

# DM All Friends
@api_router.post("/dm/all-friends")
async def dm_all_friends(request: DMAllFriendsRequest):
    task_ids = []
    
    for i, token in enumerate(request.tokens):
        token_stripped = token.strip()
        if not token_stripped:
            continue
        
        task_id = f"dm_friends_{i}_{uuid.uuid4().hex[:8]}"
        task_ids.append(task_id)
        dm_all_progress[task_id] = {"status": "running", "sent": 0, "failed": 0}
        
        async def run_task(t=token_stripped, tid=task_id):
            result = await dm_all_friends_task(t, request.message, request.delay, tid)
            dm_all_progress[tid] = {"status": "completed", **result}
        
        task = asyncio.create_task(run_task())
        dm_all_tasks[task_id] = task
    
    return {"message": "DM All Friends started", "task_ids": task_ids}

# DM All Server Members
@api_router.post("/dm/all-server")
async def dm_all_server(request: DMAllServerRequest):
    task_ids = []
    
    for i, token in enumerate(request.tokens):
        token_stripped = token.strip()
        if not token_stripped:
            continue
        
        task_id = f"dm_server_{i}_{uuid.uuid4().hex[:8]}"
        task_ids.append(task_id)
        dm_all_progress[task_id] = {"status": "running", "sent": 0, "failed": 0}
        
        async def run_task(t=token_stripped, gid=request.guild_id, tid=task_id):
            result = await dm_all_server_task(t, gid, request.message, request.delay, tid)
            dm_all_progress[tid] = {"status": "completed", **result}
        
        task = asyncio.create_task(run_task())
        dm_all_tasks[task_id] = task
    
    return {"message": "DM All Server started", "task_ids": task_ids}

# Get DM All Progress
@api_router.get("/dm/progress")
async def get_dm_progress():
    return dm_all_progress

# Stop DM All
@api_router.post("/dm/stop")
async def stop_dm_all():
    for task in dm_all_tasks.values():
        task.cancel()
    dm_all_tasks.clear()
    dm_all_progress.clear()
    return {"message": "DM All stopped"}

# Utils
@api_router.post("/extract-tokens")
async def extract_tokens_from_text(request: ExtractTokensRequest):
    tokens = extract_discord_tokens(request.text)
    return {"tokens": tokens, "count": len(tokens)}

@api_router.post("/validate-token")
async def validate_single_token(data: dict):
    token = data.get("token", "").strip()
    if not token:
        return {"valid": False, "error": "Token requis"}
    async with aiohttp.ClientSession() as session:
        return await validate_token(session, token)

app.include_router(api_router)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

@app.on_event("shutdown")
async def shutdown():
    for task in active_tasks.values():
        task.cancel()
    for task in spam_tasks.values():
        task.cancel()
    client.close()
