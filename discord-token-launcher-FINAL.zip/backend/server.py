from fastapi import FastAPI, APIRouter, HTTPException
from fastapi.responses import FileResponse
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field, ConfigDict
from typing import List, Optional, Dict
import uuid
from datetime import datetime, timezone
import asyncio
import aiohttp
import json
import random

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB is optional for Electron desktop mode
mongo_url = os.environ.get('MONGO_URL', '')
db = None
if mongo_url:
    try:
        client = AsyncIOMotorClient(mongo_url)
        db = client[os.environ.get('DB_NAME', 'discord_launcher')]
    except Exception:
        db = None

# In-memory fallback for configurations when MongoDB is unavailable
in_memory_configs: list = []

app = FastAPI()
api_router = APIRouter(prefix="/api")

# Global state
token_connections: Dict[str, dict] = {}
active_tasks: Dict[str, asyncio.Task] = {}
spam_tasks: Dict[str, asyncio.Task] = {}
dm_all_tasks: Dict[str, asyncio.Task] = {}
dm_all_progress: Dict[str, dict] = {}
join_progress: Dict[str, dict] = {}
join_tasks: Dict[str, asyncio.Task] = {}

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

DISCORD_API = "https://discord.com/api/v10"
CAPTCHA_API_KEY = os.environ.get("CAPTCHA_API_KEY", "")
CAPMONSTER_URL = "https://api.capmonster.cloud"

# ============ MODELS ============

class TokenItem(BaseModel):
    token: str
    label: Optional[str] = None
    status: str = "idle"

class ConfigurationCreate(BaseModel):
    name: str
    guild_id: str
    channel_id: str
    tokens: List[TokenItem]

class Configuration(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    guild_id: str
    channel_id: str
    tokens: List[TokenItem]
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class LaunchRequest(BaseModel):
    guild_id: str
    channel_id: str
    tokens: List[str]
    invite_code: Optional[str] = None

class SpamRequest(BaseModel):
    channel_id: str
    tokens: List[str]
    messages: List[str]
    delay: float = 1.0
    random_delay: bool = False

class StatusRequest(BaseModel):
    tokens: List[str]
    status: str

class NicknameRequest(BaseModel):
    guild_id: str
    tokens: List[str]
    nickname: str

class ReactionRequest(BaseModel):
    channel_id: str
    message_id: str
    tokens: List[str]
    emoji: str

class DMRequest(BaseModel):
    user_id: str
    tokens: List[str]
    message: str

class DMAllFriendsRequest(BaseModel):
    tokens: List[str]
    message: str
    delay: float = 1.0

class DMAllServerRequest(BaseModel):
    guild_id: str
    channel_id: Optional[str] = None
    user_ids: Optional[List[str]] = None  # Manual list of user IDs
    tokens: List[str]
    message: str
    delay: float = 1.0

class ExtractTokensRequest(BaseModel):
    text: str

class CaptchaSettingsRequest(BaseModel):
    enabled: bool = True
    service: str = "capmonster"
    api_key: Optional[str] = None

class MassJoinRequest(BaseModel):
    invite_code: str
    tokens: List[str]
    delay: float = 1.0

# Global captcha settings
captcha_settings = {"enabled": True, "service": "capmonster", "api_key": CAPTCHA_API_KEY}
captcha_stats = {"solved": 0, "failed": 0, "total_cost": 0.0}

# ============ CAPTCHA SOLVER ============

async def solve_hcaptcha(session: aiohttp.ClientSession, sitekey: str, page_url: str, rqdata: str = None, user_agent: str = None) -> dict:
    """Solve hCaptcha using CapMonster Cloud API"""
    api_key = captcha_settings.get("api_key") or CAPTCHA_API_KEY
    if not api_key:
        return {"success": False, "error": "Pas de clé API captcha configurée"}
    
    if not sitekey:
        return {"success": False, "error": "Sitekey manquant dans la réponse Discord"}
    
    logger.info(f"Résolution hCaptcha: sitekey={sitekey[:20]}... rqdata={'oui' if rqdata else 'non'}")
    
    # Create task
    task_data = {
        "type": "HCaptchaTaskProxyless",
        "websiteURL": page_url,
        "websiteKey": sitekey,
    }
    if rqdata:
        task_data["data"] = rqdata
        task_data["type"] = "HCaptchaTaskProxyless"
    if user_agent:
        task_data["userAgent"] = user_agent
    
    try:
        async with session.post(f"{CAPMONSTER_URL}/createTask", json={
            "clientKey": api_key,
            "task": task_data
        }) as resp:
            text = await resp.text()
            result = json.loads(text)
            if result.get("errorId", 0) != 0:
                error_msg = result.get("errorDescription", result.get("errorCode", "Unknown"))
                logger.error(f"Captcha createTask error: {error_msg}")
                return {"success": False, "error": error_msg}
            task_id = result.get("taskId")
            if not task_id:
                return {"success": False, "error": "Pas de taskId retourné"}
        
        logger.info(f"Captcha task créée: {task_id}")
        
        # Poll for result (max 120 seconds)
        for attempt in range(40):
            await asyncio.sleep(3)
            async with session.post(f"{CAPMONSTER_URL}/getTaskResult", json={
                "clientKey": api_key,
                "taskId": task_id
            }) as resp:
                text = await resp.text()
                result = json.loads(text)
                if result.get("errorId", 0) != 0:
                    error_msg = result.get("errorDescription", result.get("errorCode", "Unknown"))
                    logger.error(f"Captcha getResult error: {error_msg}")
                    captcha_stats["failed"] += 1
                    return {"success": False, "error": error_msg}
                
                status = result.get("status")
                if status == "ready":
                    solution = result.get("solution", {})
                    token = solution.get("gRecaptchaResponse") or solution.get("token")
                    if token:
                        logger.info(f"Captcha résolu! (attempt {attempt + 1})")
                        captcha_stats["solved"] += 1
                        return {"success": True, "token": token}
                    else:
                        captcha_stats["failed"] += 1
                        return {"success": False, "error": "Solution sans token"}
                elif status == "processing":
                    continue
                else:
                    captcha_stats["failed"] += 1
                    return {"success": False, "error": f"Status inattendu: {status}"}
        
        captcha_stats["failed"] += 1
        return {"success": False, "error": "Timeout (120s)"}
    except Exception as e:
        captcha_stats["failed"] += 1
        return {"success": False, "error": str(e)}

async def detect_captcha(response_data: dict) -> dict:
    """Check if a Discord API response contains a captcha challenge"""
    if isinstance(response_data, dict):
        captcha_key = response_data.get("captcha_key")
        captcha_sitekey = response_data.get("captcha_sitekey")
        captcha_service = response_data.get("captcha_service")
        if captcha_key or captcha_sitekey:
            return {
                "is_captcha": True,
                "sitekey": captcha_sitekey,
                "service": captcha_service or "hcaptcha",
                "rqdata": response_data.get("captcha_rqdata"),
                "rqtoken": response_data.get("captcha_rqtoken"),
            }
    return {"is_captcha": False}

async def discord_request_with_captcha(session: aiohttp.ClientSession, method: str, url: str, token: str, json_data: dict = None, max_retries: int = 2) -> dict:
    """Make a Discord API request with automatic captcha solving"""
    headers = get_headers(token)
    
    for attempt in range(max_retries + 1):
        try:
            if method == "POST":
                resp = await session.post(url, headers=headers, json=json_data)
            elif method == "PUT":
                resp = await session.put(url, headers=headers, json=json_data)
            elif method == "PATCH":
                resp = await session.patch(url, headers=headers, json=json_data)
            else:
                resp = await session.get(url, headers=headers)
            
            status = resp.status
            
            # Rate limit
            if status == 429:
                data = await resp.json()
                retry_after = data.get("retry_after", 5)
                logger.warning(f"Rate limit, attente {retry_after}s")
                await asyncio.sleep(retry_after)
                continue
            
            # Check for captcha (usually 400 or 403)
            if status in (400, 403):
                try:
                    data = await resp.json()
                except Exception:
                    return {"status": status, "success": False, "data": {}, "error": f"HTTP {status}"}
                
                captcha_info = await detect_captcha(data)
                if captcha_info["is_captcha"] and captcha_settings.get("enabled"):
                    logger.info(f"Captcha détecté! Tentative de résolution... (attempt {attempt + 1})")
                    
                    solve_result = await solve_hcaptcha(
                        session,
                        sitekey=captcha_info["sitekey"],
                        page_url="https://discord.com/channels/@me",
                        rqdata=captcha_info.get("rqdata"),
                        user_agent=headers.get("User-Agent")
                    )
                    
                    if solve_result["success"]:
                        # Retry with captcha solution
                        payload = dict(json_data) if json_data else {}
                        payload["captcha_key"] = solve_result["token"]
                        if captcha_info.get("rqtoken"):
                            payload["captcha_rqtoken"] = captcha_info["rqtoken"]
                        json_data = payload
                        logger.info("Captcha résolu, nouvelle tentative...")
                        continue
                    else:
                        logger.warning(f"Échec résolution captcha: {solve_result['error']}")
                        return {"status": status, "success": False, "data": data, "error": f"Captcha non résolu: {solve_result['error']}"}
                
                return {"status": status, "success": False, "data": data, "error": f"HTTP {status}"}
            
            # Success
            if status in (200, 201, 204):
                try:
                    data = await resp.json() if status != 204 else {}
                except Exception:
                    data = {}
                return {"status": status, "success": True, "data": data}
            
            # Other errors
            try:
                data = await resp.json()
            except Exception:
                data = {}
            return {"status": status, "success": False, "data": data, "error": f"HTTP {status}"}
            
        except Exception as e:
            if attempt < max_retries:
                await asyncio.sleep(1)
                continue
            return {"status": 0, "success": False, "data": {}, "error": str(e)}
    
    return {"status": 0, "success": False, "data": {}, "error": "Max retries atteint"}

# ============ HELPERS ============

def get_headers(token: str) -> dict:
    return {
        "Authorization": token,
        "Content-Type": "application/json",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
        "X-Super-Properties": "eyJvcyI6IldpbmRvd3MiLCJicm93c2VyIjoiQ2hyb21lIiwiZGV2aWNlIjoiIiwic3lzdGVtX2xvY2FsZSI6ImZyIiwiYnJvd3Nlcl91c2VyX2FnZW50IjoiTW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzEzMS4wLjAuMCBTYWZhcmkvNTM3LjM2IiwiYnJvd3Nlcl92ZXJzaW9uIjoiMTMxLjAuMC4wIiwib3NfdmVyc2lvbiI6IjEwIiwicmVmZXJyZXIiOiIiLCJyZWZlcnJpbmdfZG9tYWluIjoiIiwicmVmZXJyZXJfY3VycmVudCI6IiIsInJlZmVycmluZ19kb21haW5fY3VycmVudCI6IiIsInJlbGVhc2VfY2hhbm5lbCI6InN0YWJsZSIsImNsaWVudF9idWlsZF9udW1iZXIiOjMzNTU3MiwiY2xpZW50X2V2ZW50X3NvdXJjZSI6bnVsbCwiZGVzaWduX2lkIjowfQ==",
        "X-Discord-Locale": "fr",
        "X-Discord-Timezone": "Europe/Paris",
        "Origin": "https://discord.com",
        "Referer": "https://discord.com/channels/@me",
        "Sec-Ch-Ua": '"Chromium";v="131", "Not_A Brand";v="24"',
        "Sec-Ch-Ua-Mobile": "?0",
        "Sec-Ch-Ua-Platform": '"Windows"',
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "same-origin",
    }

async def validate_token(session: aiohttp.ClientSession, token: str) -> dict:
    try:
        async with session.get(f"{DISCORD_API}/users/@me", headers=get_headers(token)) as resp:
            if resp.status == 200:
                data = await resp.json()
                flags = data.get("flags", 0)  # noqa: F841
                public_flags = data.get("public_flags", 0)  # noqa: F841
                phone = data.get("phone")
                email = data.get("email")
                verified = data.get("verified", False)
                return {
                    "valid": True, 
                    "username": f"{data['username']}#{data.get('discriminator', '0')}", 
                    "id": data["id"],
                    "email": email,
                    "phone": "Oui" if phone else "Non",
                    "verified": verified,
                }
            elif resp.status == 401:
                return {"valid": False, "error": "Token invalide ou expiré (banni?)"}
            elif resp.status == 403:
                return {"valid": False, "error": "Token banni ou verrouillé par Discord"}
            elif resp.status == 429:
                data = await resp.json()
                return {"valid": False, "error": f"Rate limit - réessaie dans {data.get('retry_after', '?')}s"}
            else:
                text = await resp.text()
                return {"valid": False, "error": f"Erreur {resp.status}: {text[:100]}"}
    except Exception as e:
        return {"valid": False, "error": str(e)}

async def join_server_with_invite(session: aiohttp.ClientSession, token: str, invite_code: str) -> dict:
    if "discord.gg/" in invite_code:
        invite_code = invite_code.split("discord.gg/")[-1]
    elif "discord.com/invite/" in invite_code:
        invite_code = invite_code.split("discord.com/invite/")[-1]
    invite_code = invite_code.strip().split("?")[0].split("/")[0]
    
    import base64
    try:
        import tls_client
        has_tls = True
    except ImportError:
        has_tls = False
    
    DISCORD_DESKTOP_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) discord/1.0.310 Chrome/120.0.6099.291 Electron/28.2.7 Safari/537.36"
    DISCORD_SUPER_PROPS = "eyJvcyI6IldpbmRvd3MiLCJicm93c2VyIjoiRGlzY29yZCBDbGllbnQiLCJyZWxlYXNlX2NoYW5uZWwiOiJzdGFibGUiLCJjbGllbnRfdmVyc2lvbiI6IjEuMC4zMTAiLCJvc192ZXJzaW9uIjoiMTAuMC4yNjEwMCIsIm9zX2FyY2giOiJ4NjQiLCJhcHBfYXJjaCI6Ing2NCIsInN5c3RlbV9sb2NhbGUiOiJmciIsImJyb3dzZXJfdXNlcl9hZ2VudCI6Ik1vemlsbGEvNS4wIChXaW5kb3dzIE5UIDEwLjA7IFdpbjY0OyB4NjQpIEFwcGxlV2ViS2l0LzUzNy4zNiAoS0hUTUwsIGxpa2UgR2Vja28pIGRpc2NvcmQvMS4wLjMxMCBDaHJvbWUvMTIwLjAuNjA5OS4yOTEgRWxlY3Ryb24vMjguMi43IFNhZmFyaS81MzcuMzYiLCJicm93c2VyX3ZlcnNpb24iOiIyOC4yLjciLCJjbGllbnRfYnVpbGRfbnVtYmVyIjozMzU1NzIsIm5hdGl2ZV9idWlsZF9udW1iZXIiOm51bGwsImNsaWVudF9ldmVudF9zb3VyY2UiOm51bGwsImRlc2lnbl9pZCI6MH0="
    
    ctx = json.dumps({"location": "Join Guild", "location_guild_id": None, "location_channel_id": None, "location_channel_type": None}, separators=(',', ':'))
    x_context = base64.b64encode(ctx.encode()).decode()
    
    base_headers = {
        "Authorization": token,
        "Content-Type": "application/json",
        "User-Agent": DISCORD_DESKTOP_UA,
        "X-Super-Properties": DISCORD_SUPER_PROPS,
        "X-Context-Properties": x_context,
        "X-Discord-Locale": "fr",
        "X-Discord-Timezone": "Europe/Paris",
        "Origin": "https://discord.com",
        "Referer": f"https://discord.com/invite/{invite_code}",
    }
    
    def _sync_join(payload, extra_headers=None):
        """Execute join request synchronously with optional extra headers for captcha"""
        req_headers = dict(base_headers)
        if extra_headers:
            req_headers.update(extra_headers)
        try:
            if has_tls:
                tls_session = tls_client.Session(client_identifier="chrome_120", random_tls_extension_order=True)
                resp = tls_session.post(f"https://discord.com/api/v9/invites/{invite_code}", headers=req_headers, json=payload)
                return resp.status_code, resp.text
            else:
                import urllib.request
                req = urllib.request.Request(f"https://discord.com/api/v9/invites/{invite_code}", data=json.dumps(payload).encode(), headers=req_headers, method="POST")
                with urllib.request.urlopen(req) as resp:
                    return resp.status, resp.read().decode()
        except Exception as e:
            error_str = str(e)
            if hasattr(e, 'read'):
                error_str = e.read().decode()
            return 0, error_str
    
    for attempt in range(3):
        try:
            session_id = uuid.uuid4().hex[:32]
            payload = {"session_id": session_id}
            
            loop = asyncio.get_event_loop()
            status, raw_text = await loop.run_in_executor(None, _sync_join, payload, None)
            logger.info(f"[JOIN] Token ...{token[-8:]}: HTTP {status} - Response: {raw_text[:500]}")
            
            if status in (200, 201):
                data = json.loads(raw_text)
                return {"success": True, "guild_name": data.get("guild", {}).get("name", "Unknown")}
            
            if status == 429:
                try:
                    data = json.loads(raw_text)
                    wait = data.get("retry_after", 5)
                except Exception:
                    wait = 5
                await asyncio.sleep(wait)
                continue
            
            try:
                data = json.loads(raw_text)
            except Exception:
                data = {}
            
            captcha_info = await detect_captcha(data)
            if captcha_info["is_captcha"]:
                logger.info(f"[JOIN] Captcha détecté! sitekey={captcha_info.get('sitekey', 'NONE')[:30] if captcha_info.get('sitekey') else 'NONE'}... rqdata={'oui' if captcha_info.get('rqdata') else 'non'} rqtoken={'oui' if captcha_info.get('rqtoken') else 'non'}")
                
                if captcha_settings.get("enabled") and captcha_settings.get("api_key"):
                    solve_result = await solve_hcaptcha(
                        session, 
                        sitekey=captcha_info["sitekey"], 
                        page_url=f"https://discord.com/invite/{invite_code}", 
                        rqdata=captcha_info.get("rqdata"), 
                        user_agent=DISCORD_DESKTOP_UA
                    )
                    
                    if solve_result["success"]:
                        logger.info(f"[JOIN] Captcha résolu! Envoi de la requête avec captcha_key...")
                        
                        # Build captcha payload
                        captcha_payload = {
                            "session_id": session_id, 
                            "captcha_key": solve_result["token"]
                        }
                        if captcha_info.get("rqtoken"):
                            captcha_payload["captcha_rqtoken"] = captcha_info["rqtoken"]
                        
                        # Build extra headers for captcha request (per Discord docs)
                        captcha_headers = {}
                        if captcha_info.get("rqtoken"):
                            captcha_headers["X-Captcha-Rqtoken"] = captcha_info["rqtoken"]
                        
                        status2, raw2 = await loop.run_in_executor(None, _sync_join, captcha_payload, captcha_headers)
                        logger.info(f"[JOIN] Après captcha: HTTP {status2} - Response: {raw2[:500]}")
                        
                        if status2 in (200, 201):
                            data2 = json.loads(raw2)
                            return {"success": True, "guild_name": data2.get("guild", {}).get("name", "Unknown")}
                        
                        try:
                            data2 = json.loads(raw2)
                            err_msg = data2.get("message", f"HTTP {status2}")
                            # Check if it's another captcha (shouldn't happen but let's log)
                            if data2.get("captcha_sitekey"):
                                logger.warning(f"[JOIN] Discord a renvoyé un nouveau captcha après résolution!")
                                err_msg = "Discord a rejeté le captcha (nouveau captcha demandé)"
                        except Exception:
                            err_msg = f"HTTP {status2}"
                        return {"success": False, "error": err_msg}
                    else:
                        error_detail = solve_result.get('error', 'Unknown error')
                        logger.warning(f"[JOIN] Échec résolution captcha: {error_detail}")
                        return {"success": False, "error": f"Captcha: {error_detail}"}
                else:
                    return {"success": False, "error": "Captcha requis (clé CapMonster manquante)"}
            
            err_msg = data.get("message", f"HTTP {status}")
            if data.get("code"):
                err_msg = f"{err_msg} ({data['code']})"
            return {"success": False, "error": err_msg}
        except Exception as e:
            if attempt < 2:
                await asyncio.sleep(1)
                continue
            return {"success": False, "error": str(e)}
    
    return {"success": False, "error": "Max retries"}

def extract_discord_tokens(text: str) -> List[str]:
    import re
    pattern = r'[MNO][A-Za-z0-9_-]{17,}[A-Za-z0-9]\.[A-Za-z0-9_-]{6}\.[A-Za-z0-9_-]{27,38}'
    matches = re.findall(pattern, text)
    unique_tokens = []
    for token in matches:
        is_substring = any(token in existing for existing in unique_tokens)
        if not is_substring:
            unique_tokens = [t for t in unique_tokens if t not in token]
            unique_tokens.append(token)
    return unique_tokens

# ============ VOICE FUNCTIONS ============

async def join_voice_channel(session: aiohttp.ClientSession, token: str, guild_id: str, channel_id: str, token_id: str, invite_code: Optional[str] = None):
    import websockets
    
    token_connections[token_id] = {"status": "connecting", "error": None, "username": None}
    
    try:
        validation = await validate_token(session, token)
        if not validation["valid"]:
            token_connections[token_id] = {"status": "error", "error": validation["error"], "username": None}
            return
        
        username = validation["username"]
        token_connections[token_id]["username"] = username
        
        async with session.get(f"{DISCORD_API}/guilds/{guild_id}", headers=get_headers(token)) as resp:
            if resp.status == 404:
                if invite_code:
                    join_result = await join_server_with_invite(session, token, invite_code)
                    if not join_result["success"]:
                        token_connections[token_id] = {"status": "error", "error": join_result['error'], "username": username}
                        return
                    await asyncio.sleep(2)
                else:
                    token_connections[token_id] = {"status": "error", "error": "Pas dans le serveur", "username": username}
                    return
        
        async with session.get(f"{DISCORD_API}/gateway") as resp:
            gateway_data = await resp.json()
            gateway_url = gateway_data["url"] + "?v=10&encoding=json"
        
        async with websockets.connect(gateway_url) as ws:
            hello = json.loads(await ws.recv())
            heartbeat_interval = hello["d"]["heartbeat_interval"] / 1000
            
            await ws.send(json.dumps({
                "op": 2,
                "d": {
                    "token": token,
                    "intents": 1 << 7 | 1 << 0,
                    "properties": {"os": "windows", "browser": "chrome", "device": "pc"}
                }
            }))
            
            async def heartbeat_loop():
                while True:
                    await asyncio.sleep(heartbeat_interval)
                    await ws.send(json.dumps({"op": 1, "d": None}))
            
            heartbeat_task = asyncio.create_task(heartbeat_loop())
            
            try:
                for _ in range(20):
                    try:
                        msg = await asyncio.wait_for(ws.recv(), timeout=10)
                        event = json.loads(msg)
                        if event.get("op") == 0 and event.get("t") == "READY":
                            break
                    except asyncio.TimeoutError:
                        continue
                
                await ws.send(json.dumps({
                    "op": 4,
                    "d": {"guild_id": guild_id, "channel_id": channel_id, "self_mute": False, "self_deaf": True}
                }))
                
                for _ in range(15):
                    try:
                        msg = await asyncio.wait_for(ws.recv(), timeout=5)
                        event = json.loads(msg)
                        if event.get("op") == 0 and event.get("t") == "VOICE_STATE_UPDATE":
                            if event["d"].get("channel_id") == channel_id:
                                token_connections[token_id] = {"status": "connected", "error": None, "username": username}
                                break
                    except asyncio.TimeoutError:
                        continue
                
                while token_connections.get(token_id, {}).get("status") == "connected":
                    try:
                        msg = await asyncio.wait_for(ws.recv(), timeout=heartbeat_interval + 5)
                        event = json.loads(msg)
                        if event.get("op") == 0 and event.get("t") == "VOICE_STATE_UPDATE":
                            if event["d"].get("channel_id") is None:
                                token_connections[token_id] = {"status": "disconnected", "error": None, "username": username}
                                break
                    except:
                        break
                        
            finally:
                heartbeat_task.cancel()
                
    except Exception as e:
        token_connections[token_id] = {"status": "error", "error": str(e)[:50], "username": token_connections.get(token_id, {}).get("username")}

async def launch_token(token: str, guild_id: str, channel_id: str, token_id: str, invite_code: Optional[str] = None):
    async with aiohttp.ClientSession() as session:
        await join_voice_channel(session, token, guild_id, channel_id, token_id, invite_code)

# ============ SPAM FUNCTIONS ============

async def spam_messages(token: str, channel_id: str, messages: List[str], delay: float, random_delay: bool, task_id: str):
    async with aiohttp.ClientSession() as session:
        validation = await validate_token(session, token)
        if not validation["valid"]:
            return
        
        while task_id in spam_tasks:
            message = random.choice(messages)
            try:
                result = await discord_request_with_captcha(
                    session, "POST",
                    f"{DISCORD_API}/channels/{channel_id}/messages",
                    token,
                    json_data={"content": message}
                )
                if not result["success"]:
                    logger.warning(f"Spam message failed: {result.get('error')}")
            except Exception as e:
                logger.error(f"Spam error: {e}")
            
            wait_time = delay
            if random_delay:
                wait_time = random.uniform(delay * 0.5, delay * 1.5)
            await asyncio.sleep(wait_time)

# ============ STATUS FUNCTIONS ============

async def change_status(token: str, status: str) -> dict:
    import websockets
    
    async with aiohttp.ClientSession() as session:
        try:
            async with session.get(f"{DISCORD_API}/gateway") as resp:
                gateway_data = await resp.json()
                gateway_url = gateway_data["url"] + "?v=10&encoding=json"
            
            async with websockets.connect(gateway_url) as ws:
                await ws.recv()
                await ws.send(json.dumps({
                    "op": 2,
                    "d": {
                        "token": token,
                        "intents": 0,
                        "properties": {"os": "windows", "browser": "chrome", "device": "pc"},
                        "presence": {"status": status, "since": 0, "activities": [], "afk": False}
                    }
                }))
                await asyncio.sleep(2)
                return {"success": True}
        except Exception as e:
            return {"success": False, "error": str(e)}

# ============ OTHER FUNCTIONS ============

async def change_nickname(session: aiohttp.ClientSession, token: str, guild_id: str, nickname: str) -> dict:
    result = await discord_request_with_captcha(
        session, "PATCH",
        f"{DISCORD_API}/guilds/{guild_id}/members/@me",
        token,
        json_data={"nick": nickname}
    )
    return {"success": result["success"], "error": result.get("error")}

async def add_reaction(session: aiohttp.ClientSession, token: str, channel_id: str, message_id: str, emoji: str) -> dict:
    import urllib.parse
    encoded_emoji = urllib.parse.quote(emoji)
    result = await discord_request_with_captcha(
        session, "PUT",
        f"{DISCORD_API}/channels/{channel_id}/messages/{message_id}/reactions/{encoded_emoji}/@me",
        token
    )
    return {"success": result["success"], "error": result.get("error")}

async def send_dm(session: aiohttp.ClientSession, token: str, user_id: str, message: str) -> dict:
    try:
        # Create DM channel with captcha support
        result = await discord_request_with_captcha(
            session, "POST",
            f"{DISCORD_API}/users/@me/channels",
            token,
            json_data={"recipient_id": user_id}
        )
        
        if not result["success"]:
            error = result.get("error", "Unknown")
            if result["status"] == 403:
                return {"success": False, "error": "DM bloqué (403) - DMs fermés ou token limité"}
            return {"success": False, "error": f"DM channel error: {error}"}
        
        dm_channel_id = result["data"].get("id")
        if not dm_channel_id:
            return {"success": False, "error": "Pas de channel DM retourné"}
        
        # Send message with captcha support
        msg_result = await discord_request_with_captcha(
            session, "POST",
            f"{DISCORD_API}/channels/{dm_channel_id}/messages",
            token,
            json_data={"content": message}
        )
        
        if msg_result["success"]:
            return {"success": True}
        error = msg_result.get("error", "Unknown")
        if msg_result["status"] == 403:
            return {"success": False, "error": "Message bloqué (403) - DMs fermés"}
        return {"success": False, "error": f"Send error: {error}"}
    except Exception as e:
        return {"success": False, "error": str(e)}
    except Exception as e:
        return {"success": False, "error": str(e)}

async def get_friends(session: aiohttp.ClientSession, token: str) -> list:
    """Get all friends of a token"""
    try:
        async with session.get(
            f"{DISCORD_API}/users/@me/relationships",
            headers=get_headers(token)
        ) as resp:
            if resp.status == 200:
                relationships = await resp.json()
                # Filter only friends (type 1)
                friends = [r for r in relationships if r.get("type") == 1]
                return friends
            return []
    except:
        return []

async def get_guild_members(session: aiohttp.ClientSession, token: str, guild_id: str, channel_id: str = None) -> list:
    """Get members of a guild - optimized for user tokens"""
    members = []
    seen_ids = set()
    
    logger.info(f"Fetching members for guild {guild_id}, channel {channel_id}")
    
    # First check if token can access the guild
    try:
        async with session.get(
            f"{DISCORD_API}/guilds/{guild_id}",
            headers=get_headers(token)
        ) as resp:
            if resp.status == 403:
                logger.error(f"Token doesn't have access to guild {guild_id} - not a member?")
                return []
            elif resp.status == 404:
                logger.error(f"Guild {guild_id} not found")
                return []
            elif resp.status == 200:
                guild_data = await resp.json()
                logger.info(f"Token has access to guild: {guild_data.get('name', 'Unknown')}")
    except Exception as e:
        logger.error(f"Error checking guild access: {e}")
    
    try:
        # If specific channel provided, get members from that channel's messages
        if channel_id:
            logger.info(f"Scraping members from channel {channel_id}")
            try:
                # First check channel access
                async with session.get(
                    f"{DISCORD_API}/channels/{channel_id}",
                    headers=get_headers(token)
                ) as resp:
                    if resp.status == 200:
                        ch_data = await resp.json()
                        logger.info(f"Channel accessible: {ch_data.get('name', 'Unknown')} (type: {ch_data.get('type')})")
                    else:
                        logger.error(f"Cannot access channel {channel_id}: {resp.status}")
                        text = await resp.text()
                        logger.error(f"Response: {text[:200]}")
                
                # Get messages
                last_message_id = None
                for batch_num in range(10):
                    url = f"{DISCORD_API}/channels/{channel_id}/messages?limit=100"
                    if last_message_id:
                        url += f"&before={last_message_id}"
                    
                    async with session.get(url, headers=get_headers(token)) as resp:
                        if resp.status == 200:
                            messages = await resp.json()
                            if not messages:
                                break
                            
                            for msg in messages:
                                author = msg.get("author", {})
                                user_id = author.get("id")
                                if user_id and user_id not in seen_ids and not author.get("bot"):
                                    seen_ids.add(user_id)
                                    members.append({"user": author})
                                
                                for mention in msg.get("mentions", []):
                                    mid = mention.get("id")
                                    if mid and mid not in seen_ids and not mention.get("bot"):
                                        seen_ids.add(mid)
                                        members.append({"user": mention})
                            
                            last_message_id = messages[-1]["id"]
                            logger.info(f"Batch {batch_num + 1}: found {len(members)} unique members so far")
                        else:
                            logger.error(f"Failed to get messages: {resp.status}")
                            text = await resp.text()
                            logger.error(f"Response: {text[:200]}")
                            break
                    
                    await asyncio.sleep(0.5)
                
            except Exception as e:
                logger.error(f"Error scraping channel: {e}")
        
        # Method 2: Try to get channels and scrape from all of them
        if len(members) < 50:
            logger.info("Trying to get members from guild channels...")
            try:
                async with session.get(
                    f"{DISCORD_API}/guilds/{guild_id}/channels",
                    headers=get_headers(token)
                ) as resp:
                    if resp.status == 200:
                        channels = await resp.json()
                        text_channels = [c for c in channels if c.get("type") == 0][:5]
                        logger.info(f"Found {len(text_channels)} text channels to scrape")
                        
                        for ch in text_channels:
                            try:
                                async with session.get(
                                    f"{DISCORD_API}/channels/{ch['id']}/messages?limit=100",
                                    headers=get_headers(token)
                                ) as msg_resp:
                                    if msg_resp.status == 200:
                                        msgs = await msg_resp.json()
                                        for m in msgs:
                                            author = m.get("author", {})
                                            uid = author.get("id")
                                            if uid and uid not in seen_ids and not author.get("bot"):
                                                seen_ids.add(uid)
                                                members.append({"user": author})
                                await asyncio.sleep(0.3)
                            except:
                                continue
                    else:
                        logger.warning(f"Cannot get channels: {resp.status}")
            except Exception as e:
                logger.error(f"Error getting channels: {e}")
        
        # Method 3: Member search
        if len(members) < 30:
            logger.info("Trying member search...")
            for query in "aeiou":
                try:
                    async with session.get(
                        f"{DISCORD_API}/guilds/{guild_id}/members/search?query={query}&limit=100",
                        headers=get_headers(token)
                    ) as resp:
                        if resp.status == 200:
                            batch = await resp.json()
                            for m in batch:
                                uid = m.get("user", {}).get("id")
                                if uid and uid not in seen_ids:
                                    seen_ids.add(uid)
                                    members.append(m)
                            logger.info(f"Search '{query}' found {len(batch)} members")
                        elif resp.status == 403:
                            logger.warning("No search permission")
                            break
                    await asyncio.sleep(0.3)
                except:
                    continue
        
        logger.info(f"Final member count: {len(members)}")
        return members
        
    except Exception as e:
        logger.error(f"get_guild_members error: {e}")
        return members

async def dm_all_friends_task(token: str, message: str, delay: float, task_id: str):
    """Send DM to all friends of a token"""
    async with aiohttp.ClientSession() as session:
        validation = await validate_token(session, token)
        if not validation["valid"]:
            return {"sent": 0, "failed": 0, "error": validation["error"]}
        
        friends = await get_friends(session, token)
        sent = 0
        failed = 0
        
        for friend in friends:
            if task_id not in dm_all_tasks:
                break  # Task was cancelled
            
            user_id = friend.get("id")
            if not user_id:
                continue
            
            result = await send_dm(session, token, user_id, message)
            if result.get("success"):
                sent += 1
            else:
                failed += 1
            
            await asyncio.sleep(delay)
        
        return {"sent": sent, "failed": failed, "total_friends": len(friends)}

async def dm_all_server_task(token: str, guild_id: str, message: str, delay: float, task_id: str, channel_id: str = None, user_ids: list = None):
    """Send DM to all members of a server"""
    async with aiohttp.ClientSession() as session:
        validation = await validate_token(session, token)
        if not validation["valid"]:
            dm_all_progress[task_id] = {"status": "error", "sent": 0, "failed": 0, "error": validation["error"]}
            return {"sent": 0, "failed": 0, "error": validation["error"]}
        
        current_user_id = validation.get("id")
        logger.info(f"Starting DM All Server for token {task_id}, guild {guild_id}, channel {channel_id}, manual_ids={len(user_ids) if user_ids else 0}")
        
        members = []
        
        # If manual user IDs provided, use those directly
        if user_ids and len(user_ids) > 0:
            logger.info(f"Using {len(user_ids)} manually provided user IDs")
            for uid in user_ids:
                uid = uid.strip()
                if uid and uid != current_user_id:
                    members.append({"user": {"id": uid, "username": f"User_{uid[:6]}"}})
        else:
            # Auto-scrape members from guild
            members = await get_guild_members(session, token, guild_id, channel_id)
        
        logger.info(f"Found {len(members)} members to DM")
        
        if not members:
            error_msg = "Aucun membre trouvé"
            if not user_ids:
                error_msg += " - Essaie d'entrer les User IDs manuellement ou utilise un Channel ID"
            dm_all_progress[task_id] = {"status": "completed", "sent": 0, "failed": 0, "total": 0, "error": error_msg}
            return {"sent": 0, "failed": 0, "error": error_msg}
        
        sent = 0
        failed = 0
        blocked = 0
        total = len(members)
        errors_detail = []
        
        for i, member in enumerate(members):
            if task_id not in dm_all_tasks:
                break
            
            user = member.get("user", {})
            user_id = user.get("id")
            username = user.get("username", "Unknown")
            
            if not user_id or user.get("bot") or user_id == current_user_id:
                continue
            
            result = await send_dm(session, token, user_id, message)
            if result.get("success"):
                sent += 1
                logger.info(f"DM sent to {username} ({sent}/{total})")
            else:
                failed += 1
                error = result.get("error", "Unknown")
                if "403" in str(error) or "bloqué" in str(error):
                    blocked += 1
                if len(errors_detail) < 5:
                    errors_detail.append(f"{username}: {error}")
                logger.warning(f"Failed to DM {username}: {error}")
            
            dm_all_progress[task_id] = {
                "status": "running", 
                "sent": sent, 
                "failed": failed, 
                "blocked": blocked,
                "total": total,
                "current": i + 1,
                "errors_detail": errors_detail
            }
            await asyncio.sleep(delay)
        
        final_error = None
        if sent == 0 and failed > 0:
            if blocked == failed:
                final_error = "Tous les DMs bloqués (403) - Le token est peut-être banni ou les utilisateurs ont les DMs fermés"
            else:
                final_error = f"{failed} échecs - Token potentiellement limité par Discord"
        
        logger.info(f"DM All Server completed: {sent} sent, {failed} failed, {blocked} blocked")
        dm_all_progress[task_id] = {
            "status": "completed", 
            "sent": sent, 
            "failed": failed, 
            "blocked": blocked,
            "total": total,
            "error": final_error,
            "errors_detail": errors_detail
        }
        return {"sent": sent, "failed": failed, "blocked": blocked, "total_members": total}

# ============ API ROUTES ============

@api_router.get("/")
async def root():
    return {"message": "Discord Token Launcher API - Multi-Tools"}

# Download ZIP
@api_router.get("/download-zip")
async def download_zip():
    zip_path = "/app/discord-token-launcher-electron.zip"
    if os.path.exists(zip_path):
        return FileResponse(zip_path, filename="discord-token-launcher-electron.zip", media_type="application/zip")
    raise HTTPException(status_code=404, detail="ZIP file not found")

# Mass Join Server (background task)
async def _join_server_task(invite_code: str, tokens: List[str], delay: float, task_id: str):
    join_progress[task_id] = {"status": "running", "total": len(tokens), "current": 0, "success": 0, "failed": 0, "results": []}
    async with aiohttp.ClientSession() as session:
        valid_tokens = [(i, t.strip()) for i, t in enumerate(tokens) if t.strip()]
        join_progress[task_id]["total"] = len(valid_tokens)
        for idx, (i, token_stripped) in enumerate(valid_tokens):
            if task_id not in join_tasks:
                break
            join_result = await join_server_with_invite(session, token_stripped, invite_code)
            result = {
                "token_index": i,
                "username": join_result.get("guild_name", ""),
                "success": join_result.get("success", False),
                "guild_name": join_result.get("guild_name"),
                "error": join_result.get("error")
            }
            join_progress[task_id]["results"].append(result)
            if result["success"]:
                join_progress[task_id]["success"] += 1
            else:
                join_progress[task_id]["failed"] += 1
            join_progress[task_id]["current"] = idx + 1
            if idx < len(valid_tokens) - 1:
                await asyncio.sleep(delay)
    join_progress[task_id]["status"] = "completed"

@api_router.post("/join-server")
async def mass_join_server(request: MassJoinRequest):
    task_id = f"join_{uuid.uuid4().hex[:8]}"
    task = asyncio.create_task(_join_server_task(request.invite_code, request.tokens, request.delay, task_id))
    join_tasks[task_id] = task
    return {"message": "Join lancé en arrière-plan", "task_id": task_id}

@api_router.get("/join-server/progress")
async def get_join_progress():
    if not join_progress:
        return {}
    latest_key = list(join_progress.keys())[-1]
    return join_progress.get(latest_key, {})

@api_router.post("/join-server/stop")
async def stop_join():
    for tid, task in list(join_tasks.items()):
        task.cancel()
        del join_tasks[tid]
        if tid in join_progress:
            join_progress[tid]["status"] = "stopped"
    return {"message": "Join arrêté"}

# Configurations
@api_router.post("/configurations", response_model=Configuration)
async def create_configuration(config: ConfigurationCreate):
    config_obj = Configuration(**config.model_dump())
    doc = config_obj.model_dump()
    doc['created_at'] = doc['created_at'].isoformat()
    doc['updated_at'] = doc['updated_at'].isoformat()
    if db is not None:
        await db.configurations.insert_one(doc)
    else:
        in_memory_configs.append(doc)
    return config_obj

@api_router.get("/configurations", response_model=List[Configuration])
async def get_configurations():
    if db is not None:
        configs = await db.configurations.find({}, {"_id": 0}).to_list(100)
    else:
        configs = list(in_memory_configs)
    for config in configs:
        if isinstance(config.get('created_at'), str):
            config['created_at'] = datetime.fromisoformat(config['created_at'])
        if isinstance(config.get('updated_at'), str):
            config['updated_at'] = datetime.fromisoformat(config['updated_at'])
    return configs

@api_router.delete("/configurations/{config_id}")
async def delete_configuration(config_id: str):
    if db is not None:
        await db.configurations.delete_one({"id": config_id})
    else:
        in_memory_configs[:] = [c for c in in_memory_configs if c.get("id") != config_id]
    return {"message": "Deleted"}

# Voice
@api_router.post("/launch")
async def launch_tokens(request: LaunchRequest):
    token_ids = []
    tokens_to_launch = []
    
    for i, token in enumerate(request.tokens):
        token_stripped = token.strip()
        if not token_stripped:
            continue
        token_id = f"token_{i}_{uuid.uuid4().hex[:8]}"
        token_ids.append(token_id)
        token_connections[token_id] = {"status": "pending", "error": None, "username": None}
        tokens_to_launch.append((token_stripped, token_id))
    
    async def launch_batch():
        for i in range(0, len(tokens_to_launch), 5):
            batch = tokens_to_launch[i:i + 5]
            for token_stripped, token_id in batch:
                task = asyncio.create_task(launch_token(token_stripped, request.guild_id, request.channel_id, token_id, request.invite_code))
                active_tasks[token_id] = task
            if i + 5 < len(tokens_to_launch):
                await asyncio.sleep(2)
    
    asyncio.create_task(launch_batch())
    return {"message": "Launch initiated", "token_ids": token_ids}

@api_router.get("/status")
async def get_token_status():
    return token_connections

@api_router.post("/disconnect")
async def disconnect_all():
    for task in active_tasks.values():
        task.cancel()
    active_tasks.clear()
    token_connections.clear()
    return {"message": "Disconnected"}

# Spam
@api_router.post("/spam/start")
async def start_spam(request: SpamRequest):
    task_ids = []
    for i, token in enumerate(request.tokens):
        token_stripped = token.strip()
        if not token_stripped:
            continue
        task_id = f"spam_{i}_{uuid.uuid4().hex[:8]}"
        task_ids.append(task_id)
        task = asyncio.create_task(spam_messages(token_stripped, request.channel_id, request.messages, request.delay, request.random_delay, task_id))
        spam_tasks[task_id] = task
    return {"message": "Spam started", "task_ids": task_ids}

@api_router.post("/spam/stop")
async def stop_spam():
    for task in spam_tasks.values():
        task.cancel()
    spam_tasks.clear()
    return {"message": "Spam stopped"}

# Status
@api_router.post("/status/change")
async def change_all_status(request: StatusRequest):
    results = []
    for token in request.tokens:
        if token.strip():
            results.append(await change_status(token.strip(), request.status))
    success = sum(1 for r in results if r.get("success"))
    return {"message": f"Status changed for {success}/{len(results)} tokens"}

# Nickname
@api_router.post("/nickname/change")
async def change_all_nicknames(request: NicknameRequest):
    results = []
    async with aiohttp.ClientSession() as session:
        for token in request.tokens:
            if token.strip():
                results.append(await change_nickname(session, token.strip(), request.guild_id, request.nickname))
                await asyncio.sleep(0.5)
    success = sum(1 for r in results if r.get("success"))
    return {"message": f"Nickname changed for {success}/{len(results)} tokens"}

# Reactions
@api_router.post("/reaction/add")
async def add_all_reactions(request: ReactionRequest):
    results = []
    async with aiohttp.ClientSession() as session:
        for token in request.tokens:
            if token.strip():
                results.append(await add_reaction(session, token.strip(), request.channel_id, request.message_id, request.emoji))
                await asyncio.sleep(0.3)
    success = sum(1 for r in results if r.get("success"))
    return {"message": f"Reaction added by {success}/{len(results)} tokens"}

# DM
@api_router.post("/dm/send")
async def send_all_dms(request: DMRequest):
    results = []
    async with aiohttp.ClientSession() as session:
        for token in request.tokens:
            if token.strip():
                results.append(await send_dm(session, token.strip(), request.user_id, request.message))
                await asyncio.sleep(1)
    success = sum(1 for r in results if r.get("success"))
    return {"message": f"DM sent by {success}/{len(results)} tokens"}

# DM All Friends
@api_router.post("/dm/all-friends")
async def dm_all_friends(request: DMAllFriendsRequest):
    task_ids = []
    
    for i, token in enumerate(request.tokens):
        token_stripped = token.strip()
        if not token_stripped:
            continue
        
        task_id = f"dm_friends_{i}_{uuid.uuid4().hex[:8]}"
        task_ids.append(task_id)
        dm_all_progress[task_id] = {"status": "running", "sent": 0, "failed": 0}
        
        async def run_task(t=token_stripped, tid=task_id):
            result = await dm_all_friends_task(t, request.message, request.delay, tid)
            dm_all_progress[tid] = {"status": "completed", **result}
        
        task = asyncio.create_task(run_task())
        dm_all_tasks[task_id] = task
    
    return {"message": "DM All Friends started", "task_ids": task_ids}

# DM All Server Members
@api_router.post("/dm/all-server")
async def dm_all_server(request: DMAllServerRequest):
    task_ids = []
    
    for i, token in enumerate(request.tokens):
        token_stripped = token.strip()
        if not token_stripped:
            continue
        
        task_id = f"dm_server_{i}_{uuid.uuid4().hex[:8]}"
        task_ids.append(task_id)
        dm_all_progress[task_id] = {"status": "running", "sent": 0, "failed": 0}
        
        async def run_task(t=token_stripped, gid=request.guild_id, cid=request.channel_id, uids=request.user_ids, tid=task_id):
            result = await dm_all_server_task(t, gid, request.message, request.delay, tid, cid, uids)
            dm_all_progress[tid] = {"status": "completed", **result}
        
        task = asyncio.create_task(run_task())
        dm_all_tasks[task_id] = task
    
    return {"message": "DM All Server started", "task_ids": task_ids}

# Get DM All Progress
@api_router.get("/dm/progress")
async def get_dm_progress():
    return dm_all_progress

# Stop DM All
@api_router.post("/dm/stop")
async def stop_dm_all():
    for task in dm_all_tasks.values():
        task.cancel()
    dm_all_tasks.clear()
    dm_all_progress.clear()
    return {"message": "DM All stopped"}

# Utils
@api_router.post("/extract-tokens")
async def extract_tokens_from_text(request: ExtractTokensRequest):
    tokens = extract_discord_tokens(request.text)
    return {"tokens": tokens, "count": len(tokens)}

@api_router.post("/validate-token")
async def validate_single_token(data: dict):
    token = data.get("token", "").strip()
    if not token:
        return {"valid": False, "error": "Token requis"}
    async with aiohttp.ClientSession() as session:
        result = await validate_token(session, token)
        
        if result.get("valid"):
            # Get guilds list
            try:
                async with session.get(
                    f"{DISCORD_API}/users/@me/guilds",
                    headers=get_headers(token)
                ) as resp:
                    if resp.status == 200:
                        guilds = await resp.json()
                        result["guilds"] = [{"id": g["id"], "name": g["name"]} for g in guilds[:20]]
                        result["guild_count"] = len(guilds)
                    elif resp.status == 403:
                        result["warning"] = "Token limité - impossible de lister les serveurs"
            except:
                pass
            
            # Check if token can send DMs (quick test)
            try:
                async with session.get(
                    f"{DISCORD_API}/users/@me/channels",
                    headers=get_headers(token)
                ) as resp:
                    if resp.status == 200:
                        dms = await resp.json()
                        result["dm_channels"] = len(dms)
                    elif resp.status == 403:
                        result["dm_warning"] = "Token ne peut pas accéder aux DMs - potentiellement limité"
            except:
                pass
        
        return result

@api_router.post("/check-guild-access")
async def check_guild_access(data: dict):
    """Check if token has access to a specific guild"""
    token = data.get("token", "").strip()
    guild_id = data.get("guild_id", "").strip()
    
    if not token or not guild_id:
        return {"access": False, "error": "Token and guild_id required"}
    
    async with aiohttp.ClientSession() as session:
        # Check if token is valid
        validation = await validate_token(session, token)
        if not validation.get("valid"):
            return {"access": False, "error": validation.get("error")}
        
        # Check guild access
        try:
            async with session.get(
                f"{DISCORD_API}/guilds/{guild_id}",
                headers=get_headers(token)
            ) as resp:
                if resp.status == 200:
                    guild_data = await resp.json()
                    return {
                        "access": True, 
                        "guild_name": guild_data.get("name"),
                        "member_count": guild_data.get("approximate_member_count")
                    }
                elif resp.status == 403:
                    return {"access": False, "error": "Token n'est pas membre de ce serveur"}
                elif resp.status == 404:
                    return {"access": False, "error": "Serveur non trouvé"}
                else:
                    return {"access": False, "error": f"Erreur {resp.status}"}
        except Exception as e:
            return {"access": False, "error": str(e)}

# ============ CAPTCHA API ROUTES ============

@api_router.get("/captcha/stats")
async def get_captcha_stats():
    return {**captcha_stats, "enabled": captcha_settings.get("enabled", False), "has_key": bool(captcha_settings.get("api_key"))}

@api_router.post("/captcha/settings")
async def update_captcha_settings(data: dict):
    if "enabled" in data:
        captcha_settings["enabled"] = data["enabled"]
    if "api_key" in data and data["api_key"]:
        captcha_settings["api_key"] = data["api_key"]
    return {"message": "Settings updated", **captcha_settings, "api_key": "***" if captcha_settings.get("api_key") else None}

@api_router.post("/captcha/test")
async def test_captcha_solver():
    """Test the captcha solver with a simple hCaptcha"""
    api_key = captcha_settings.get("api_key") or CAPTCHA_API_KEY
    if not api_key:
        return {"success": False, "error": "Pas de clé API captcha"}
    
    async with aiohttp.ClientSession() as session:
        try:
            async with session.post(f"{CAPMONSTER_URL}/getBalance", json={"clientKey": api_key}) as resp:
                text = await resp.text()
                result = json.loads(text)
                if result.get("errorId", 0) != 0:
                    return {"success": False, "error": f"Clé API invalide: {result.get('errorDescription', 'Unknown')}"}
                balance = result.get("balance", 0)
                return {"success": True, "balance": balance, "message": f"Connecté! Solde: ${balance:.4f}"}
        except Exception as e:
            return {"success": False, "error": str(e)}

app.include_router(api_router)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

@app.on_event("shutdown")
async def shutdown():
    for task in active_tasks.values():
        task.cancel()
    for task in spam_tasks.values():
        task.cancel()
    if db is not None:
        client.close()
