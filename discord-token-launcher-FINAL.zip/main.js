const { app, BrowserWindow, dialog } = require('electron');
const path = require('path');
const { spawn, exec, execSync } = require('child_process');
const http = require('http');
const fs = require('fs');

let mainWindow;
let pythonProcess = null;
const BACKEND_PORT = 8001;

function getBackendPath() {
  return path.join(__dirname, 'backend');
}

function log(message) {
  const timestamp = new Date().toISOString();
  console.log(`[${timestamp}] ${message}`);
}

function checkBackendReady() {
  return new Promise((resolve) => {
    let attempts = 0;
    const maxAttempts = 120; // 60 seconds max
    
    const check = () => {
      attempts++;
      if (attempts % 10 === 0) {
        log(`Checking backend... attempt ${attempts}`);
      }
      
      http.get(`http://127.0.0.1:${BACKEND_PORT}/api/`, (res) => {
        if (res.statusCode === 200) {
          log('Backend is ready!');
          resolve(true);
        } else {
          if (attempts < maxAttempts) {
            setTimeout(check, 500);
          } else {
            resolve(false);
          }
        }
      }).on('error', () => {
        if (attempts < maxAttempts) {
          setTimeout(check, 500);
        } else {
          resolve(false);
        }
      });
    };
    check();
  });
}

function findPythonSync() {
  const commands = process.platform === 'win32' 
    ? ['python', 'py', 'python3'] 
    : ['python3', 'python'];
  
  for (const cmd of commands) {
    try {
      const result = execSync(`${cmd} --version`, { encoding: 'utf8', timeout: 5000 });
      log(`Found Python: ${cmd} - ${result.trim()}`);
      return cmd;
    } catch (e) {
      // Continue to next
    }
  }
  return null;
}

function installDependencies(pythonCmd, backendPath) {
  return new Promise((resolve) => {
    const requirementsPath = path.join(backendPath, 'requirements.txt');
    
    if (!fs.existsSync(requirementsPath)) {
      log('requirements.txt not found, skipping install');
      resolve(true);
      return;
    }
    
    log('Installing Python dependencies...');
    
    const pipCmd = process.platform === 'win32' ? 'pip' : 'pip3';
    
    // Try pip install
    const install = spawn(pythonCmd, ['-m', 'pip', 'install', '-r', 'requirements.txt', '--quiet'], {
      cwd: backendPath,
      shell: true,
      windowsHide: true
    });
    
    let output = '';
    install.stdout.on('data', (data) => {
      output += data.toString();
    });
    install.stderr.on('data', (data) => {
      output += data.toString();
    });
    
    install.on('close', (code) => {
      if (code === 0) {
        log('Dependencies installed successfully');
        resolve(true);
      } else {
        log(`Pip install failed with code ${code}: ${output}`);
        resolve(false);
      }
    });
    
    install.on('error', (err) => {
      log(`Pip install error: ${err.message}`);
      resolve(false);
    });
    
    // Timeout after 60 seconds
    setTimeout(() => {
      install.kill();
      log('Pip install timeout');
      resolve(false);
    }, 60000);
  });
}

async function startBackend() {
  const backendPath = getBackendPath();
  log(`Backend path: ${backendPath}`);
  
  // Check if server.py exists
  const serverPath = path.join(backendPath, 'server.py');
  if (!fs.existsSync(serverPath)) {
    log(`ERROR: server.py not found at ${serverPath}`);
    return false;
  }
  log('server.py found');
  
  // Find Python
  const pythonCmd = findPythonSync();
  if (!pythonCmd) {
    log('ERROR: Python not found!');
    return false;
  }
  
  // Install dependencies
  await installDependencies(pythonCmd, backendPath);
  
  // Set environment
  const env = { 
    ...process.env, 
    PYTHONUNBUFFERED: '1',
    PYTHONIOENCODING: 'utf-8',
    MONGO_URL: '',
    DB_NAME: 'discord_launcher'
  };
  
  // Read .env file if exists
  const envPath = path.join(backendPath, '.env');
  if (fs.existsSync(envPath)) {
    const envContent = fs.readFileSync(envPath, 'utf8');
    envContent.split('\n').forEach(line => {
      const match = line.match(/^([^=]+)=(.*)$/);
      if (match) {
        const key = match[1].trim();
        const value = match[2].trim();
        if (key && value) {
          env[key] = value;
        }
      }
    });
    log('Loaded .env file');
  }
  
  log(`Starting backend with: ${pythonCmd} -m uvicorn server:app --host 127.0.0.1 --port ${BACKEND_PORT}`);
  
  try {
    pythonProcess = spawn(pythonCmd, [
      '-m', 'uvicorn',
      'server:app',
      '--host', '127.0.0.1',
      '--port', BACKEND_PORT.toString()
    ], {
      cwd: backendPath,
      env: env,
      shell: true,
      windowsHide: true
    });
    
    pythonProcess.stdout.on('data', (data) => {
      log(`Backend: ${data.toString().trim()}`);
    });
    
    pythonProcess.stderr.on('data', (data) => {
      const msg = data.toString().trim();
      log(`Backend: ${msg}`);
      
      // Check for common errors
      if (msg.includes('ModuleNotFoundError') || msg.includes('No module named')) {
        log('Missing Python module detected!');
      }
    });
    
    pythonProcess.on('error', (err) => {
      log(`Backend process error: ${err.message}`);
    });
    
    pythonProcess.on('close', (code) => {
      log(`Backend process exited with code ${code}`);
      pythonProcess = null;
    });
    
    return true;
  } catch (err) {
    log(`Failed to start backend: ${err.message}`);
    return false;
  }
}

function createWindow(backendReady = true) {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 1000,
    minHeight: 700,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js'),
      webSecurity: false
    },
    icon: path.join(__dirname, 'assets', 'icon.ico'),
    backgroundColor: '#0A0A0A',
    show: false,
    titleBarStyle: 'default',
    title: 'Discord Token Launcher'
  });

  mainWindow.setMenuBarVisibility(false);

  const htmlPath = path.join(__dirname, 'frontend', 'index.html');
  log(`Loading frontend from: ${htmlPath}`);
  mainWindow.loadFile(htmlPath);

  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
    if (!backendReady) {
      dialog.showMessageBox(mainWindow, {
        type: 'warning',
        title: 'Attention',
        message: 'Le backend n\'a pas démarré correctement. Certaines fonctionnalités peuvent ne pas fonctionner.\n\nAssurez-vous que Python est installé et exécutez:\npip install -r backend/requirements.txt',
        buttons: ['OK']
      });
    }
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

app.whenReady().then(async () => {
  log('App starting...');
  
  const backendStarted = await startBackend();
  
  if (backendStarted) {
    log('Waiting for backend to be ready...');
    const backendReady = await checkBackendReady();
    createWindow(backendReady);
  } else {
    log('Backend failed to start');
    createWindow(false);
  }
});

app.on('window-all-closed', () => {
  log('All windows closed');
  if (pythonProcess) {
    log('Killing backend process...');
    if (process.platform === 'win32') {
      try {
        execSync(`taskkill /pid ${pythonProcess.pid} /f /t`, { windowsHide: true });
      } catch (e) {}
    } else {
      pythonProcess.kill('SIGTERM');
    }
  }
  app.quit();
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});

app.on('before-quit', () => {
  log('App quitting...');
  if (pythonProcess) {
    if (process.platform === 'win32') {
      try {
        execSync(`taskkill /pid ${pythonProcess.pid} /f /t`, { windowsHide: true });
      } catch (e) {}
    } else {
      pythonProcess.kill('SIGTERM');
    }
  }
});
